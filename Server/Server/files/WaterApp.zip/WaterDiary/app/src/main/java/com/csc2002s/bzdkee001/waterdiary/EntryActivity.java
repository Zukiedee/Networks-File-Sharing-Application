package com.csc2002s.bzdkee001.waterdiary;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

public class EntryActivity extends AppCompatActivity {
    public static String filename =".txt";

    int id;
    Date date;
    double total;
    double bodyWAshing;
    double toilet;
    double hygiene;
    double brushingTeeth;
    double laundry;
    double dishes;
    double drinking;
    double cooking;
    double cleaning;
    double pets;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entry);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }

    public void enterData () {

        String out = getString(R.string.printOut);
        filename = Integer.toString(id)+filename;

        FileOutputStream fileOutputStream = null;
        File file = new File(filename);

        try {
            fileOutputStream = openFileOutput(filename, MODE_PRIVATE);
            try {
                fileOutputStream.write(out.getBytes());
            } catch (IOException e) {
                e.printStackTrace();
            }
            Toast.makeText(this, "Entry Created", Toast.LENGTH_SHORT).show();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                fileOutputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}

