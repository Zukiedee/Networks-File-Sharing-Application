package com.csc2002s.bzdkee001.waterdiary;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.csc2002s.bzdkee001.waterdiary.model.Entry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<String> entryIDs = new ArrayList<>();
    public static final String FILE_NAME =".txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        for (int i = 1; i < 32; i++) {
            entryIDs.add(Integer.toString(i) + "/" + "08/" + Integer.toString(2018) + " --- Total usage: " + Integer.toString(i*i));
        }


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_1, entryIDs);

        ListView listView = (ListView)findViewById(android.R.id.list);
        listView.setAdapter(adapter);
    }

    public void createEntry (View view) {
        Intent intent = new Intent(this, EntryActivity.class);
        startActivity(intent);

    }
}
