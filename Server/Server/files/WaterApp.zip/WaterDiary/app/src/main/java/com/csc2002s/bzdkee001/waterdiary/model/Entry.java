package com.csc2002s.bzdkee001.waterdiary.model;

public class Entry {

    private String Id;
    private String date;
    private double total;
    private double bodyWashing;
    private double toilet;
    private double hygiene;
    private double brushingTeeth;
    private double laundry;
    private double dishes;
    private double drinking;
    private double cooking;
    private double cleaning;
    private double pets;

    public Entry() {
    }

    public Entry(String id, String date, double total, double bodyWashing, double toilet, double hygiene, double brushingTeeth, double laundry, double dishes, double drinking, double cooking, double cleaning, double pets) {
        Id = id;
        this.date = date;
        this.total = total;
        this.bodyWashing = bodyWashing;
        this.toilet = toilet;
        this.hygiene = hygiene;
        this.brushingTeeth = brushingTeeth;
        this.laundry = laundry;
        this.dishes = dishes;
        this.drinking = drinking;
        this.cooking = cooking;
        this.cleaning = cleaning;
        this.pets = pets;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public double getBodyWashing() {
        return bodyWashing;
    }

    public void setBodyWashing(double bodyWashing) {
        this.bodyWashing = bodyWashing;
    }

    public double getToilet() {
        return toilet;
    }

    public void setToilet(double toilet) {
        this.toilet = toilet;
    }

    public double getHygiene() {
        return hygiene;
    }

    public void setHygiene(double hygiene) {
        this.hygiene = hygiene;
    }

    public double getBrushingTeeth() {
        return brushingTeeth;
    }

    public void setBrushingTeeth(double brushingTeeth) {
        this.brushingTeeth = brushingTeeth;
    }

    public double getLaundry() {
        return laundry;
    }

    public void setLaundry(double laundry) {
        this.laundry = laundry;
    }

    public double getDishes() {
        return dishes;
    }

    public void setDishes(double dishes) {
        this.dishes = dishes;
    }

    public double getDrinking() {
        return drinking;
    }

    public void setDrinking(double drinking) {
        this.drinking = drinking;
    }

    public double getCooking() {
        return cooking;
    }

    public void setCooking(double cooking) {
        this.cooking = cooking;
    }

    public double getCleaning() {
        return cleaning;
    }

    public void setCleaning(double cleaning) {
        this.cleaning = cleaning;
    }

    public double getPets() {
        return pets;
    }

    public void setPets(double pets) {
        this.pets = pets;
    }

    @Override
    public String toString() {
        return "Entry{" +
                "Id='" + Id + '\'' +
                ", date='" + date + '\'' +
                ", total=" + total +
                ", bodyWashing=" + bodyWashing +
                ", toilet=" + toilet +
                ", hygiene=" + hygiene +
                ", brushingTeeth=" + brushingTeeth +
                ", laundry=" + laundry +
                ", dishes=" + dishes +
                ", drinking=" + drinking +
                ", cooking=" + cooking +
                ", cleaning=" + cleaning +
                ", pets=" + pets +
                '}';
    }
}
